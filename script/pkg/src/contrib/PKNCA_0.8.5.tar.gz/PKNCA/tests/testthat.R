library(testthat)
library(PKNCA)

test_check("PKNCA")
