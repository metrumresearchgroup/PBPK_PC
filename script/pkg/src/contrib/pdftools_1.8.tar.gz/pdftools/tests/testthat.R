library(testthat)
library(pdftools)

test_check("pdftools")
